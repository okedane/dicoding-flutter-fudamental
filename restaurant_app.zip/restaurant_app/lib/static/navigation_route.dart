enum NavigationRoute {
  mainRoute("/"),
  detailRoute("/detail");

  const NavigationRoute(this.name);
  final String name;
}
